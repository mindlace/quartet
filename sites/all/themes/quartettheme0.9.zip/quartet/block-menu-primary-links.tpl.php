<?php
// $Id: block-menu-primary-links.tpl.php
?>
<div class="<?php print "block block-$block->module" ?>" id="<?php print "block-$block->module-$block->delta"; ?>">
  <div class="content"><div class="large-menu"><?php print $block->content ?></div></div>
</div>